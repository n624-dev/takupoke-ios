"""Preserve pinned dependency notices before the owned runtime build is deleted."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

def preserve_notices(checkouts: Path, destination: Path, resolved: Path):
    lock=json.loads(resolved.read_text())
    expected={pin['identity'].lower():pin['state']['revision'] for pin in lock['pins']}
    roots=sorted(path for path in checkouts.iterdir() if path.is_dir())
    assert any(path.name=='coreai-models' for path in roots), 'Pinned official runtime checkout missing'
    destination.mkdir(parents=True,exist_ok=True)
    inventory=[];pins=[]
    for root in roots:
        revision=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
        assert expected.get(root.name.lower())==revision, 'Actual dependency checkout does not match Package.resolved'
        if root.name=='coreai-models':
            assert revision=='52c84ba874b2c57adcede08a671ce96ed1b3f433', 'Official runtime source revision changed'
        pins.append(dict(package=root.name,revision=revision))
        count_before=len(inventory)
        for path in sorted(root.rglob('*')):
            if not path.is_file() or path.is_symlink() or '.git' in path.relative_to(root).parts: continue
            name=path.name.upper()
            normalized=''.join(char for char in name if char.isalnum())
            if not name.startswith(('LICENSE','LICENCE','NOTICE','COPYING')) and not normalized.startswith(('THIRDPARTYNOTICE','THIRDPARTYLICENSE','THIRDPARTYLICENCE')): continue
            assert path.stat().st_size<=2_000_000, 'Unexpected oversized notice'
            assert len(inventory)<1024, 'Unexpected notice count'
            relative=Path(root.name)/path.relative_to(root)
            target=destination/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
            inventory.append(dict(path=relative.as_posix(),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest()))
        assert len(inventory)>count_before, 'Actual dependency checkout has no retained license/notice'
    assert inventory, 'No third-party notices preserved'
    (destination/'SOURCE-NOTICES.json').write_text(json.dumps(dict(scope='Source license/notice files from actual pinnedruntime dependency checkouts; compiled applicability to be checked alongside binary receipt',sourcePins=pins,files=inventory),indent=2)+'\n')
