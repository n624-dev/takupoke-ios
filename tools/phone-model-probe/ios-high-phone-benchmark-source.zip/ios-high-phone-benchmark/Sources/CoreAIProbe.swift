// Research-only native component probe. Never add this to a release target.
// Uses production load/inference paths with a documented research-only awaited
// unload selector in the copied runtime/C bridge. No catalog or fake validated
// manifest. Inputs must be the pinned entirely fictional corpus.
// Pending Apple SDK compilation and physical execution; no quality PASS claim.
#if os(iOS) && canImport(CCoreAIRecovery) && canImport(CLlamaRecovery)
import Foundation
import Darwin
import CCoreAIRecovery
import CLlamaRecovery

struct IOSHighMemory: Codable, Sendable {
    var footprintBytes: UInt64?
    var availableProcessBytes: UInt64
    var physicalBoardBytes: UInt64
    var thermalState: Int
    static func read() -> Self {
        var info = task_vm_info_data_t()
        var count = mach_msg_type_number_t(MemoryLayout<task_vm_info_data_t>.size / MemoryLayout<integer_t>.size)
        let code = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count)
            }
        }
        return Self(footprintBytes: code == KERN_SUCCESS ? info.phys_footprint : nil,
                    availableProcessBytes: tk_llama_available_memory(),
                    physicalBoardBytes: ProcessInfo.processInfo.physicalMemory,
                    thermalState: ProcessInfo.processInfo.thermalState.rawValue)
    }
}

private actor IOSHighSampler {
    private var values = [IOSHighMemory]()
    func sample() { values.append(.read()) }
    func result() -> [IOSHighMemory] { values }
}

private final class IOSHighCoreAIHandle: @unchecked Sendable {
    let pointer: UnsafeMutableRawPointer
    private let lock = NSLock()
    private var cancellationStarted: Double?
    private var cancellationResponse: Double?
    init() throws {
        let runtime = (Bundle.main.privateFrameworksURL ?? Bundle.main.bundleURL.appendingPathComponent("Frameworks"))
            .appendingPathComponent("CoreAIRecoveryRuntime.framework/CoreAIRecoveryRuntime")
        guard let value = tk_coreai_create(runtime.path) else { throw CocoaError(.executableNotLoadable) }
        pointer = value
    }
    deinit { tk_coreai_release(pointer) }
    func cancel() {
        lock.withLock { if cancellationStarted == nil { cancellationStarted = ProcessInfo.processInfo.systemUptime } }
        tk_coreai_cancel(pointer)
    }
    func noteCompletion() {
        lock.withLock {
            if let cancellationStarted, cancellationResponse == nil {
                cancellationResponse = ProcessInfo.processInfo.systemUptime-cancellationStarted
            }
        }
    }
    var cancellationResponseSeconds: Double? { lock.withLock { cancellationResponse } }
    func unload() async throws {
        // Cleanup must still run when the calling task is already cancelled.
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            tk_coreai_unload(pointer) { error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume() }
            }
        }
    }
    func load(_ path: String) async throws {
        try await withTaskCancellationHandler {
            try Task.checkCancellation()
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                tk_coreai_load(pointer, path) { error in
                    self.noteCompletion()
                    if let error { continuation.resume(throwing: error) }
                    else { continuation.resume() }
                }
            }
            try Task.checkCancellation()
        } onCancel: { self.cancel() }
    }
    func recover(_ prompt: String) async throws -> String {
        guard prompt.utf8.count <= 8192 else { throw CocoaError(.fileReadTooLarge) }
        return try await withTaskCancellationHandler {
            try Task.checkCancellation()
            let value: String = try await withCheckedThrowingContinuation { continuation in
                tk_coreai_recover(pointer, prompt) { output, error in
                    self.noteCompletion()
                    if let error { continuation.resume(throwing: error) }
                    else if let output, output.utf8.count <= 16384 {
                        continuation.resume(returning: output)
                    } else { continuation.resume(throwing: CocoaError(.fileReadCorruptFile)) }
                }
            }
            try Task.checkCancellation()
            return value
        } onCancel: { self.cancel() }
    }
}

@available(iOS 27.0, *)
enum IOSHighPhoneCoreAIProbe {
    struct Sample: Codable {
        var operation: String
        var seconds: Double
        var rawOutput: String?
        var errorCode: Int?
        var memoryBefore: IOSHighMemory
        var memoryAfter: IOSHighMemory
    }
    struct Report: Codable {
        var scope = "Native component/runtime probe only; no production recovery qualification"
        var operatingSystem = ProcessInfo.processInfo.operatingSystemVersionString
        var modelBundleSHA256: String
        var promptSHA256: String
        var coreAIModelsRevision = "52c84ba874b2c57adcede08a671ce96ed1b3f433"
        var samples: [Sample]
        var sampledMemory: [IOSHighMemory]
        var cancellationResponseSeconds: Double?
        var samplingIntervalMilliseconds = 100
        var watchdogSeconds = 120
        var instrumentation = "Copied production load/inference plus research-only awaited state.unload selector"
    }
    // Call from a temporary research app or physical XCTest target. This API
    // writes no production state. Caller exports the returned JSON locally.
    static func run(bundleURL: URL, bundleSHA256: String, fictionalPrompt: String,
                    promptSHA256: String, repeats: Int = 3) async throws -> Data {
        guard (1...3).contains(repeats), fictionalPrompt.utf8.count <= 8192 else { throw CocoaError(.fileReadTooLarge) }
        let handle = try IOSHighCoreAIHandle(), sampler = IOSHighSampler()
        let watchdog = Task {
            do { try await Task.sleep(for: .seconds(120)); handle.cancel() } catch { }
        }
        let memoryTask = Task {
            while !Task.isCancelled {
                await sampler.sample()
                do { try await Task.sleep(for: .milliseconds(100)) } catch { break }
            }
        }
        defer { memoryTask.cancel(); watchdog.cancel() }
        var samples = [Sample]()
        let before = IOSHighMemory.read(), loadStart = ProcessInfo.processInfo.systemUptime
        do { try await handle.load(bundleURL.path) }
        catch {
            samples.append(Sample(operation: "coldLoad", seconds: ProcessInfo.processInfo.systemUptime-loadStart,
                                  errorCode: (error as NSError).code, memoryBefore: before, memoryAfter: .read()))
            return try await finish(handle: handle, sampler: sampler, memoryTask: memoryTask, watchdog: watchdog,
                                    bundleSHA256: bundleSHA256, promptSHA256: promptSHA256, samples: samples)
        }
        samples.append(Sample(operation: "coldLoad", seconds: ProcessInfo.processInfo.systemUptime-loadStart,
                              memoryBefore: before, memoryAfter: .read()))
        for index in 0..<repeats {
            if Task.isCancelled { break }
            let before = IOSHighMemory.read(), start = ProcessInfo.processInfo.systemUptime
            do {
                let raw = try await handle.recover(fictionalPrompt)
                samples.append(Sample(operation: index == 0 ? "firstGeneration" : "warmGeneration",
                                      seconds: ProcessInfo.processInfo.systemUptime-start, rawOutput: raw,
                                      memoryBefore: before, memoryAfter: .read()))
            } catch {
                samples.append(Sample(operation: "generationError", seconds: ProcessInfo.processInfo.systemUptime-start,
                                      errorCode: (error as NSError).code, memoryBefore: before, memoryAfter: .read()))
                break
            }
        }
        return try await finish(handle: handle, sampler: sampler, memoryTask: memoryTask, watchdog: watchdog,
                                bundleSHA256: bundleSHA256, promptSHA256: promptSHA256, samples: samples)
    }
    private static func finish(handle: IOSHighCoreAIHandle, sampler: IOSHighSampler,
                               memoryTask: Task<Void, Never>, watchdog: Task<Void, Never>,
                               bundleSHA256: String, promptSHA256: String, samples: [Sample]) async throws -> Data {
        watchdog.cancel(); await watchdog.value
        var completed = samples
        let before = IOSHighMemory.read(), start = ProcessInfo.processInfo.systemUptime
        do {
            try await handle.unload()
            completed.append(Sample(operation: "awaitedNativeUnload", seconds: ProcessInfo.processInfo.systemUptime-start,
                                    memoryBefore: before, memoryAfter: .read()))
        } catch {
            completed.append(Sample(operation: "unloadError", seconds: ProcessInfo.processInfo.systemUptime-start,
                                    errorCode: (error as NSError).code, memoryBefore: before, memoryAfter: .read()))
        }
        await sampler.sample(); memoryTask.cancel(); await memoryTask.value
        return try JSONEncoder().encode(Report(modelBundleSHA256: bundleSHA256, promptSHA256: promptSHA256,
                                               samples: completed, sampledMemory: await sampler.result(),
                                               cancellationResponseSeconds: handle.cancellationResponseSeconds))
    }
}
#endif
