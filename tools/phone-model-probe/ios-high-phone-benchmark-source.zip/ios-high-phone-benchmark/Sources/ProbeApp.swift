import SwiftUI
import UniformTypeIdentifiers
import CryptoKit

struct ProbeAsset: Codable, Sendable { var path: String; var bytes: Int64; var sha256: String }
struct ProbeManifest: Codable, Sendable {
    var scope: String; var bundleSHA256: String; var files: [ProbeAsset]
}
struct ProbeCase: Codable, Identifiable, Sendable { var id: String; var prompt: String; var sha256: String }
struct ImportedProbeBundle: Sendable { var url: URL; var sha256: String }

@MainActor final class ProbeScreenModel: ObservableObject {
    @Published var status = "固定した架空入力で端末内の推論を測定します。"
    @Published var running = false
    @Published var imported: ImportedProbeBundle?
    @Published var reportURL: URL?
    @Published var summary = "未実行"
    let cases: [ProbeCase]
    let manifest: ProbeManifest
    private var task: Task<Void, Never>?
    private var importTask: Task<ImportedProbeBundle, Error>?

    init() {
        let decoder = JSONDecoder()
        let corpusData = Bundle.main.url(forResource: "PinnedCorpus", withExtension: "json").flatMap { try? Data(contentsOf: $0) }
        let pinData = Bundle.main.url(forResource: "ModelBundleManifest", withExtension: "json").flatMap { try? Data(contentsOf: $0) }
        cases = corpusData.flatMap { try? decoder.decode([ProbeCase].self, from: $0) } ?? []
        manifest = pinData.flatMap { try? decoder.decode(ProbeManifest.self, from: $0) } ?? ProbeManifest(scope: "conversion pending", bundleSHA256: "", files: [])
        if manifest.files.isEmpty { status = "モデル変換が未完了の検証用ビルドです。モデルを選択できません。" }
        // Only this application's own ephemeral model copies are reclaimed.
        if let root = try? Self.cacheRoot(), let entries = try? FileManager.default.contentsOfDirectory(at: root, includingPropertiesForKeys: nil) {
            for entry in entries where entry.lastPathComponent.hasPrefix("probe-") { try? FileManager.default.removeItem(at: entry) }
        }
    }
    func cancel() { status = "中止しています…"; task?.cancel(); importTask?.cancel() }
    func importBundle(_ url: URL) {
        guard !running, !manifest.files.isEmpty else { return }
        running = true; status = "モデルをコピーしてハッシュを確認しています…"
        let pin = manifest
        let worker = Task.detached { try Self.copyVerifiedBundle(url, pin: pin) }
        importTask = worker
        task = Task {
            defer { running = false; importTask = nil; task = nil }
            do {
                let next = try await withTaskCancellationHandler { try await worker.value } onCancel: { worker.cancel() }
                do { try Task.checkCancellation() }
                catch { try? FileManager.default.removeItem(at: next.url); throw error }
                if let old = imported { try? FileManager.default.removeItem(at: old.url) }
                imported = next; status = "固定モデルを確認しました。機内モードで測定を開始できます。"
            } catch { status = error is CancellationError ? "中止しました。" : "指定した固定モデルのフォルダを確認できませんでした。" }
        }
    }
    func run() {
        guard !running, let bundle = imported, !cases.isEmpty else { return }
        running = true; status = "読み込み・推論・メモリを測定しています…"; reportURL = nil
        let inputs = cases
        task = Task {
            defer { running = false; task = nil }
            var results = [[String: Any]]()
            do {
                for item in inputs {
                    try Task.checkCancellation()
                    guard SHA256.hash(data: Data(item.prompt.utf8)).map({ String(format: "%02x", $0) }).joined() == item.sha256 else { throw CocoaError(.fileReadCorruptFile) }
                    status = "測定中: \(item.id)"
                    var recorded = false
                    do {
                        let report = try await IOSHighPhoneCoreAIProbe.run(bundleURL: bundle.url, bundleSHA256: bundle.sha256,
                            fictionalPrompt: item.prompt, promptSHA256: item.sha256, repeats: 3)
                        let decoded = try JSONSerialization.jsonObject(with: report)
                        results.append(["caseId": item.id, "report": decoded])
                        recorded = true
                        guard let object = decoded as? [String: Any], let samples = object["samples"] as? [[String: Any]],
                              samples.contains(where: { $0["operation"] as? String == "awaitedNativeUnload" }),
                              !samples.contains(where: { $0["errorCode"] != nil || ["generationError", "unloadError"].contains($0["operation"] as? String ?? "") }),
                              samples.filter({ $0["operation"] as? String == "firstGeneration" && $0["rawOutput"] is String }).count == 1,
                              samples.filter({ $0["operation"] as? String == "warmGeneration" && $0["rawOutput"] is String }).count == 2 else {
                            throw CocoaError(.executableNotLoadable)
                        }
                    } catch {
                        if !recorded {
                            results.append(["caseId": item.id, "report": ["operation": "bridgeOrReportFailure", "errorCode": (error as NSError).code,
                                "modelBundleSHA256": bundle.sha256, "promptSHA256": item.sha256, "operatingSystem": ProcessInfo.processInfo.operatingSystemVersionString]])
                        }
                        throw error
                    }
                    try Task.checkCancellation()
                }
                summary = "\(results.count)入力の実測出力を保存しました。品質合格の判定は含みません。"
                status = "完了"
            } catch { summary = "途中までの実測記録: \(results.count)入力"; status = error is CancellationError || Task.isCancelled ? "中止しました。" : "推論を完了できませんでした。" }
            if !results.isEmpty {
                let value: [String: Any] = ["scope": "Fictional native component controls only; no recovery qualification", "cases": results]
                if let data = try? JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys]),
                   let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
                    let output = docs.appendingPathComponent("model-probe-\(UUID().uuidString).json")
                    do { try data.write(to: output, options: .atomic); reportURL = output } catch { status = "測定結果を保存できませんでした。" }
                }
            }
        }
    }
    func discard() {
        guard !running else { return }
        if let imported { try? FileManager.default.removeItem(at: imported.url) }
        imported = nil; status = "検証用モデルのコピーを削除しました。"
    }
    nonisolated private static func cacheRoot() throws -> URL {
        var root = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("ModelProbe", isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        var values = URLResourceValues(); values.isExcludedFromBackup = true; try root.setResourceValues(values)
        return root
    }
    nonisolated private static func copyVerifiedBundle(_ source: URL, pin: ProbeManifest) throws -> ImportedProbeBundle {
        guard !pin.files.isEmpty, pin.files.count <= 128, pin.bundleSHA256.count == 64,
              Set(pin.files.map(\.path)).count == pin.files.count else { throw CocoaError(.fileReadCorruptFile) }
        let access = source.startAccessingSecurityScopedResource()
        defer { if access { source.stopAccessingSecurityScopedResource() } }
        let manager = FileManager.default, target = try cacheRoot().appendingPathComponent("probe-\(UUID().uuidString)", isDirectory: true)
        try manager.createDirectory(at: target, withIntermediateDirectories: true)
        var committed = false
        defer { if !committed { try? manager.removeItem(at: target) } }
        var total: Int64 = 0
        for asset in pin.files {
            try Task.checkCancellation()
            let parts = asset.path.split(separator: "/", omittingEmptySubsequences: false)
            guard !parts.isEmpty, parts.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." && !$0.contains("\\") }),
                  asset.bytes > 0, asset.bytes <= 2_000_000_000, asset.sha256.count == 64 else { throw CocoaError(.fileReadCorruptFile) }
            total += asset.bytes; guard total <= 2_500_000_000 else { throw CocoaError(.fileReadTooLarge) }
            var input = source
            for part in parts {
                input.appendPathComponent(String(part))
                guard try input.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink != true else { throw CocoaError(.fileReadCorruptFile) }
            }
            guard try input.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile == true else { throw CocoaError(.fileReadCorruptFile) }
            let output = target.appendingPathComponent(asset.path)
            try manager.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
            guard manager.createFile(atPath: output.path, contents: nil) else { throw CocoaError(.fileWriteUnknown) }
            let reader = try FileHandle(forReadingFrom: input), writer = try FileHandle(forWritingTo: output)
            defer { try? reader.close(); try? writer.close() }
            var hash = SHA256(), count: Int64 = 0
            while let chunk = try reader.read(upToCount: 262144), !chunk.isEmpty {
                try Task.checkCancellation(); count += Int64(chunk.count)
                guard count <= asset.bytes else { throw CocoaError(.fileReadTooLarge) }
                hash.update(data: chunk); try writer.write(contentsOf: chunk)
            }
            let digest = hash.finalize().map { String(format: "%02x", $0) }.joined()
            guard count == asset.bytes, digest == asset.sha256 else { throw CocoaError(.fileReadCorruptFile) }
        }
        guard manager.fileExists(atPath: target.appendingPathComponent("metadata.json").path),
              manager.fileExists(atPath: target.appendingPathComponent("tokenizer/tokenizer.json").path) else { throw CocoaError(.fileReadCorruptFile) }
        committed = true
        return ImportedProbeBundle(url: target, sha256: pin.bundleSHA256)
    }
}

@main struct ModelProbeApp: App {
    @StateObject private var model = ProbeScreenModel()
    @State private var pickingModel = false
    @Environment(\.scenePhase) private var phase
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                Form {
                    Section("端末内モデルの検証") {
                        Text("架空入力のみ。学校のPDFや時間割を読み込む機能はありません。")
                        Text("測定結果は実際の出力・処理時間・メモリです。品質合格や時間割の採用は行いません。")
                        Text(model.status).accessibilityIdentifier("probe-status")
                    }
                    Section("モデル") {
                        Button("固定モデルのフォルダを選択", systemImage: "folder") { pickingModel = true }
                            .buttonStyle(.glass).disabled(model.running || model.manifest.files.isEmpty)
                        Text(model.imported == nil ? "未選択" : "ハッシュ確認済み")
                        Button("検証用のコピーを削除", role: .destructive) { model.discard() }.disabled(model.running || model.imported == nil)
                    }
                    Section("測定") {
                        Button("架空入力で測定を開始", systemImage: "play.fill") { model.run() }
                            .buttonStyle(.glassProminent).disabled(model.running || model.imported == nil)
                        if model.running { ProgressView(); Button("中止", role: .cancel) { model.cancel() } }
                        Text("固定入力: \(model.cases.count)件。各入力を初回1回と継続2回で測定します。")
                        Text(model.summary)
                        if let report = model.reportURL { ShareLink("実測JSONを書き出す", item: report).buttonStyle(.glass) }
                    }
                }
                .navigationTitle("モデル端末検証")
                .fileImporter(isPresented: $pickingModel, allowedContentTypes: [.folder]) { outcome in
                    if case .success(let url) = outcome { model.importBundle(url) }
                }
            }
            .onChange(of: phase) { _, next in if next != .active && model.running { model.cancel() } }
        }
    }
}
